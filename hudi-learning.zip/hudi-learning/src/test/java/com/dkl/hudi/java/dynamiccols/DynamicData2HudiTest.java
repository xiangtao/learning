package com.dkl.hudi.java.dynamiccols;


import com.dkl.hudi.java.dynamiccols.DynamicData2Hudi;

public class DynamicData2HudiTest {

    public static void main(String[] args) throws Exception {
        DynamicData2Hudi dynamicData2Hudi = new DynamicData2Hudi();

        dynamicData2Hudi.execute();

    }
}
